package com.meaningfarm.mall.product;

import lombok.Data;

@Data
public class OptionVO {
	private int option_no = 0;
	private String option_name = "";
	private String option_value = "";
	private int option_stock = 0;
	private int option_price = 0;
//	public int getOption_no() {
//		return option_no;
//	}
//	public void setOption_no(int option_no) {
//		this.option_no = option_no;
//	}
//	public String getOption_name() {
//		return option_name;
//	}
//	public void setOption_name(String option_name) {
//		this.option_name = option_name;
//	}
//	public String getOption_value() {
//		return option_value;
//	}
//	public void setOption_value(String option_value) {
//		this.option_value = option_value;
//	}
//	public int getOption_stock() {
//		return option_stock;
//	}
//	public void setOption_stock(int option_stock) {
//		this.option_stock = option_stock;
//	}
//	public int getOption_price() {
//		return option_price;
//	}
//	public void setOption_price(int option_price) {
//		this.option_price = option_price;
//	}
//	public int getProduct_no() {
//		return product_no;
//	}
//	public void setProduct_no(int product_no) {
//		this.product_no = product_no;
//	}
}
