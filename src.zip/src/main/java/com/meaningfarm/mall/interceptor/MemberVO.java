package com.meaningfarm.mall.interceptor;

public class MemberVO {
	private String m_id = "";
}
